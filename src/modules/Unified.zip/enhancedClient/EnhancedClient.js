import React from "react";
export default function EnhancedClient() {
  return (
    <div className="text-xl">
      Enhanced Astrology Client Dashboard (UI coming soon)
    </div>
  );
}