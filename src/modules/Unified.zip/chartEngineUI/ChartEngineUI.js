import React from "react";
export default function ChartEngineUI() {
  return (
    <div className="text-xl">
      Chart Engine UI Components (UI coming soon)
    </div>
  );
}