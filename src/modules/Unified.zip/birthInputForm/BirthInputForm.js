import React from "react";
export default function BirthInputForm() {
  return (
    <div className="text-xl">
      Birth Input Form (UI coming soon)
    </div>
  );
}