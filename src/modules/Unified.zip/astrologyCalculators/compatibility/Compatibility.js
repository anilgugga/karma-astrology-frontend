import React from "react";
export default function Compatibility() {
  return (
    <div className="text-xl">
      Compatibility Analysis (UI coming soon)
    </div>
  );
}