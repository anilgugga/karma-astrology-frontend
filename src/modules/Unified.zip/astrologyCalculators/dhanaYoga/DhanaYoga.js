import React from "react";
export default function DhanaYoga() {
  return (
    <div className="text-xl">
      Dhana Yoga Calculator (UI coming soon)
    </div>
  );
}