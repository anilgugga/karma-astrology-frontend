import React from "react";
export default function BirthChart() {
  return (
    <div className="text-xl">
      Birth Chart Generation (UI coming soon)
    </div>
  );
}