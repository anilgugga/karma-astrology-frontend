import React from "react";
export default function IndianChartRenderers() {
  return (
    <div className="text-xl">
      Indian Chart Renderers (UI coming soon)
    </div>
  );
}