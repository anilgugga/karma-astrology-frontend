import React from "react";
export default function Dashboard() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Welcome to Your Astrology Dashboard</h1>
      <p>Navigate to different modules using the sidebar.</p>
    </div>
  );
}